#!/usr/bin/env python3


"""Fetch sequences

In this exercise you will parse out Uniprot ids for proteins involved in Covid-19
from the file UniProtKB_covid19.dat and download all the sequences from http://www.uniprot.org
into a folder named 'fasta/'

(base) touch:exercises bjornw$ head UniProtKB_covid19.dat 
ID   TMPS2_HUMAN             Reviewed;         492 AA.
AC   O15393; A8K6Z8; B2R8E5; B7Z459; D3DSJ2; F8WES1; Q6GTK7; Q9BXX1;
DT   15-JUL-1998, integrated into UniProtKB/Swiss-Prot.
DT   03-OCT-2006, sequence version 3.
DT   12-AUG-2020, entry version 190.
DE   RecName: Full=Transmembrane protease serine 2 {ECO:0000305};
DE            EC=3.4.21.-;
DE   AltName: Full=Serine protease 10 {ECO:0000305};
DE   Contains:
DE     RecName: Full=Transmembrane protease serine 2 non-catalytic chain;



The uniprot id is the the keyword following the line that starts with ID, e.g
TMPS2_HUMAN in the case above.

Given a uniprot id the url for the sequence is: http://www.uniprot.org/uniprot/TMPS2_HUMAN.fasta






"""

import sys
import argparse
import re
import urllib.request
import os

# **** Write your code code here
# Define a read_uniprot_ids function that reads the file and returns a list of uniprot ids
# 
def read_uniprot_ids(filename):
  return


# This function saves the fasta sequence in the file named outfile
# It should be able to handle the exception if the link does not exist.
def fasta_from_uniprot_id(uniprot_id,outfile):
  return



def main():
  parser=argparse.ArgumentParser(description='Regexp')
  parser.add_argument('filename',metavar='FILENAME', type=str)
  
  args=parser.parse_args()

  filename=args.filename

  #### Add your code here

  

if __name__ == '__main__':
  main()
