#!/usr/bin/env python3


"""Pipeline exercise

In this exercise we will make a simple pipeline that runs external software. You will use the
fasta sequences you retrieved in the 'fetch_sequences.py' exercise, and produce a pipeline
that runs pairwise local or global sequence alignment between all pairs of sequences, 
and extracts the score from the outfile.

To run local alignment you will use the program 'water' and for global you will use the 
program 'needle'.

The program as run as follows:
water -asequence <seqfile1> -bsequence <seqfile2> -gapopen 10 -gapextend 0.5 -outfile <outfile>
needle -asequence <seqfile1> -bsequence <seqfile2> -gapopen 10 -gapextend 0.5 -outfile <outfile>

Workflow:

0. Make an outfolder depending on if you using local or global alignment.
1. Read in all fasta files using os.listdir(...)
2. Construct all pairs from this using for instance a double for loop.
3. Construct a unique outfile based on the file name of the pair, e.g outfolder/<fasta1>-<fasta2>
4. Construct the string with the command line you want to run.
5. Print the command line make sure it is correct
6. Run the command line.
7. Use the external program grep to search for a line with the string 'Score' and get the score for the alignment
8. print the name of the two fasta files and the score

Congrats you have just made a script that made some 3000 alignments. 

"""

import sys
import argparse
import re
import subprocess
import os

# **** Write your code code here

# Call grep using subprocess.getoutput to search for the line containing the score of the alignment.

# Example alignment output:
#######################################
# Program: needle
# Rundate: Thu 20 Aug 2020 15:32:37
# Commandline: needle
#    -gapopen 10
#    -gapextend 0.5
#    -asequence fasta/IL6RB_HUMAN
#    -bsequence fasta/IL6RB_HUMAN
#    -outfile global/IL6RB_HUMAN-IL6RB_HUMAN
# Align_format: srspair
# Report_file: global/IL6RB_HUMAN-IL6RB_HUMAN
########################################

#=======================================
#
# Aligned_sequences: 2
# 1: IL6RB_HUMAN
# 2: IL6RB_HUMAN
# Matrix: EBLOSUM62
# Gap_penalty: 10.0
# Extend_penalty: 0.5
#
# Length: 918
# Identity:     918/918 (100.0%)
# Similarity:   918/918 (100.0%)
# Gaps:           0/918 ( 0.0%)
# Score: 4891.0
# 
#
#=======================================
#
#IL6RB_HUMAN        1 MLTLQTWLVQALFIFLTTESTGELLDPCGYISPESPVVQLHSNFTAVCVL     50
#                     ||||||||||||||||||||||||||||||||||||||||||||||||||
#IL6RB_HUMAN        1 MLTLQTWLVQALFIFLTTESTGELLDPCGYISPESPVVQLHSNFTAVCVL     50
#

def get_score(filename):
  return





def main():
  parser=argparse.ArgumentParser(description='Pipeline')
  parser.add_argument('folder',metavar='FOLDER', type=str)
  parser.add_argument('-l',action='store_true',default=False)
  parser.add_argument('-g',action='store_true',default=False)
  args=parser.parse_args()

  folder=args.folder
#  prefix='/usr/local/emboss/bin/'
  prefix='/courses/TFTB46/emboss/bin/'
  
  if args.l: #local alignment
    alignment_program=prefix + 'water -gapopen 10 -gapextend 0.5'
    outfolder='local'
  elif args.g: #global alignment
    alignment_program=prefix + 'needle -gapopen 10 -gapextend 0.5'
    outfolder='global'
  else:
    print('You need to give -l (local) or -g (global) argument')
    sys.exit()

  #Make outfolder if it does not exist
  if not os.path.exists(outfolder):
    os.mkdir(outfolder)
  #WRITE YOUR CODE HERE
  #write your alignment output the outfolder created above.

  
if __name__ == '__main__':
  main()
