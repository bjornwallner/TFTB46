#!/usr/bin/env python3

# String exercises
# Fill in your code in the different function.
# You can test the code by running the script using: python string.py

# A. String length
# Given a string the function should return the string:
# 'The string contain <length> characters', where <length>
# is the number of letters in the string. However if the
# string is over 10 characters long it should instead
# return the string: "The string is longer than 10 characters"
# instead of the actual length.
# Example:
# string_len('Hello') returns 'The string contain 5 characters'
# string_len('Python is cool') returns 'The string is longer than 10 characters'


def string_len(string):
    #write your code here
    return

# B: lower and upper case
# Given a string the function should return a lower case
# version of the string if the first or last character is an A,
# otherwise it should return an upper case version 

def upper_or_lower(string):
    #write your code here
    return


# C: replace_first
# Given a string s, return a new string where all occurences
# of its first characters have been replaced with '-', except
# do not change the first character.
# Example AAACCGGTA returns A--CCGGT-
# Assume that the string is length 1 or more.
# Hint: s.replace(stra, strb) returns a version of string s
# where all instances of stra have been replaced by strb.

def replace_first(s):
    #write your code here
    return



# D: mix2
# Given two strings s1 and s2, return a the single string with s1 and s2
# separated by a space '<s1> <s2>', except swap the first 2 chars of each string.
# Assume the strings are longer than 2.
# Example:
# 'protein', 'structure' -> 'stotein prructure' 
# 'protein', 'DNA' -> 'DNotein prA'

def mix2(s1,s2):
    #write your code here
    return



def test(out,expected):
    if out == expected:
        print("OK  got what I should: {}".format(expected))
    else:
        print("X  got: {}, should have gotten: {}".format(out,expected))



#Define a function that test the string functions
def main():

    print("Testing string methods...")
    print("string_len")
    test(string_len('Hello'),'The string contain 5 characters')
    test(string_len('Python'),'The string contain 6 characters')
    test(string_len('Hamburgers'),'The string contain 10 characters')
    test(string_len('Python is cool'),'The string is longer than 10 characters')
    print
    print("upper_or_lower")
    test(upper_or_lower('A is the first letter in the alphabet'),'a is the first letter in the alphabet')
    test(upper_or_lower('B is the second letter in the alphabet'),'B IS THE SECOND LETTER IN THE ALPHABET')
    test(upper_or_lower('BCDA'),'bcda')
    test(upper_or_lower('bcd'),'BCD')
    print
    print("replace_first")
    test(replace_first('AAACCGGTA'),'A--CCGGT-')
    test(replace_first('CCGG'),'C-GG')
    test(replace_first('GCGCGCGCGC'),'GC-C-C-C-C')
    test(replace_first('GCCAATTAA'),'GCCAATTAA')
    print
    print("mix2")
    test(mix2('protein', 'structure'),'stotein prructure')
    test(mix2('protein', 'DNA'),'DNotein prA')
    test(mix2('data', 'biology'),'bita daology')
    test(mix2('Python', 'Ada'),'Adthon Pya')
    #Boilerplate that calls the main() function.
if __name__ == '__main__':
    main()
