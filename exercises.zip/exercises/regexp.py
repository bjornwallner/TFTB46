#!/usr/bin/env python3


"""Regexp exercise

In this exercise you should use regexp to analys an output file from TM-align.
TM-align is a structural alignment program that compares 3D structures
of proteins. A TM-score = 1 means the two structures are identical and
TM-score = 0 that they have nothing in common. Two such records are
listed below, your task is to use regexp to fetch out relevant
information from the file.

The information you should extract is he Target, Template, and the largest 
of the two TM-scores for each record.

In the first case below it woule be: 1abtA.pdb, 10gsA.pdb, 0.32631 


Here is what TM-align output look like:
...
TM-ALIGN STARTED
Target: 1abtA.pdb chain: A
Template: 10gsA.pdb chain: A
Length of Chain_1:  74 residues
Length of Chain_2:  208 residues

Aligned length=50, RMSD=  4.39, Seq_ID=n_identical/n_aligned=0.060
TM-score=0.16535 (if normalized by length of structure B, i.e., LN=208, d0=5.37)
TM-score=0.32631 (if normalized by length of structure A, i.e., LN=74, d0=3.03)

PYTVVYF-PV-R-GRCAALRMLLADQGQSWKEEVVTVETWQEGSLKASCLYGQLPKFQDGDLTLYQSNTILRHLGRTLGLYGKDQQEAALVDMVNDGVEDLRCK----YISLIYTNYEAGKDDYVKALPGQLKPFETL-------LSQNQGGKTFIVGDQISFADYNLLDLLLIHEVLAPGCLDAFPLLSAYVG---------RLSARPKLKAFLASPEYVNLPINGNGKQ-
        .. : :::  ::.                                                                                       .:  .   .                            .     . :::.::::.  :: : ::  ::  : :::.:::: ::  :.         .:::..                       
-------IVCHTTATS--PIS-----------------------------------------------------------------------------------AVTCPP--G---E---------------------NLCYRKMW-----C-DAFCSSRGK--VV-E-LG--CA--A-TCPSKKPY-EE--VTCCSTDKCNPHPKQRP----------------------G


Total running time is  0.03 seconds
END

TM-ALIGN STARTED
Target: 1abtA.pdb chain: A
Template: 10gsB.pdb chain: A
Length of Chain_1:  74 residues
Length of Chain_2:  208 residues

Aligned length=50, RMSD=  4.39, Seq_ID=n_identical/n_aligned=0.060
TM-score=0.16535 (if normalized by length of structure B, i.e., LN=208, d0=5.37)
TM-score=0.32631 (if normalized by length of structure A, i.e., LN=74, d0=3.03)

PYTVVYF-PV-R-GRCAALRMLLADQGQSWKEEVVTVETWQEGSLKASCLYGQLPKFQDGDLTLYQSNTILRHLGRTLGLYGKDQQEAALVDMVNDGVEDLRCK----YISLIYTNYEAGKDDYVKALPGQLKPFETL-------LSQNQGGKTFIVGDQISFADYNLLDLLLIHEVLAPGCLDAFPLLSAYVG---------RLSARPKLKAFLASPEYVNLPINGNGKQ-
        .. : :::  ::.                                                                                       .:  .   .                            .     . :::.::::.  :: : ::  ::  : :::.:::: ::  :.         .:::..                       
-------IVCHTTATS--PIS-----------------------------------------------------------------------------------AVTCPP--G---E---------------------NLCYRKMW-----C-DAFCSSRGK--VV-E-LG--CA--A-TCPSKKPY-EE--VTCCSTDKCNPHPKQRP----------------------G


Total running time is  0.01 seconds
END
...




Suggest milestones for incremental development:
- Loop over each line and make regxp to extract relevant information
- You need to extract both TM-score to see which one is highest.

"""

import sys
import argparse
import re

# **** Write your code code here


def extract_tmscore(filename):
  """
  Given a filename for TM-align output, return a list of strings of the form 'target template largest_tmscore',
  where the list is sorted in from high to low tmscore, e.g. 
  ['1abtA.pdb 1a19A.pdb 0.24777', '1abtA.pdb 1aluA.pdb 0.24758', '1abtA.pdb 137lA.pdb 0.24729',....]
  """
  # **** Write your code code here
  return







def main():
  #Command line parsing is provided
  parser=argparse.ArgumentParser(description='Regexp')
  parser.add_argument('filename',metavar='FILENAME', type=str)
  parser.add_argument('-summaryfile',action='store_true',default=False)
  args=parser.parse_args()

  filename=args.filename

  
  # args.summaryfile will be true if you have given -summaryfile as an argument


  
  # Extract the TM-scores, by calling the function extract_tmscores
  # then either print the text output or write it to a summary file (if -summaryfile is given)

  # **** Write your code code here

  
if __name__ == '__main__':
  main()
