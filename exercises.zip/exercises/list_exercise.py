#!/usr/bin/env python3

# List exercises
# Fill in your code in the different function.
# You can test the code by running the script using: python list.py

# A. end_repeat
# Given a list of strings return the number of strings that are longer
# than 2 and have the two last characters the same
# Note: python does not have a ++ operator, but += works.
def end_repeat(strings):
    #write your code here
    return 

# B. sort_strings
# Given a list of strings, return a new list where which string
# has been resorted by the elements in the string
# Example:
# if the list is a=["apple orange banana","car boat airplane", "pants socks hat"] 
# it should return b=['apple banana orange', 'airplane boat car', 'hat pants socks']
# Hint: loop over the strings and use s.split("") to make a list of the elements in the string
#       sort by that list and use " ".join(list) to join the sorted elements
#       finally use .append to append the sorted string to a new list.

def sort_strings(strings):
    #write your code here
    return 



# C. sort_last
# Given a list of non-empty tuples, return a list sorted in increasing
# order by the last element in each tuple.
# e.g. [(1, 7), (1, 3), (3, 4, 5), (2, 2)] yields
# [(2, 2), (1, 3), (3, 4, 5), (1, 7)]
# Hint: use a custom key= function to extract the last element form each tuple.
def sort_last(tuples):
  # +++your code here+++
    return

def test(out,expected):
    if out == expected:
        print("OK  got what I should: {}".format(expected))
    else:
        print("X  got: {}, should have gotten: {}".format(out,expected))



#Define a function that test the string functions
def main():

    print("Testing list methods...")
    print("\nend_repeat")
    test(end_repeat(['abb','abc','aab']),1)
    test(end_repeat(['abbb','abcc','aabb']),3)
    test(end_repeat(['abbb','abcc','aabab','ata']),2)
    print("\nsort_strings")
    test(sort_strings(["apple orange banana","car boat airplane", "pants socks hat"]),['apple banana orange', 'airplane boat car', 'hat pants socks'])
    test(sort_strings(["SU KTH LiU","low high medium", "small big huge"]),['KTH LiU SU', 'high low medium', 'big huge small'])
    test(sort_strings(["5 4 3", "12 10 11","9000 4000 5000"]),['3 4 5', '10 11 12', '4000 5000 9000'])
    print("\nsort_last")
    test(sort_last([(1, 3), (3, 2), (2, 1)]),
         [(2, 1), (3, 2), (1, 3)])
    test(sort_last([(2, 3), (1, 2), (3, 1)]),
         [(3, 1), (1, 2), (2, 3)])
    test(sort_last([(1, 7), (1, 3), (3, 4, 5), (2, 2)]),
         [(2, 2), (1, 3), (3, 4, 5), (1, 7)])



    
    #Boilerplate that calls the main() function.
if __name__ == '__main__':
    main()
