#!/usr/bin/env python3


"""Organismcount exercise

The main() below is already defined and complete. It calls print_counts(filename)
and print_counts_sorted(filename) functions which you write.

1. For the -count flag, implement a print_counts(filename) function that counts
how often each organism appears in each line of the gpcr.tab textfile and prints:
organism1 count1
organims2 count2
...

Print the above list in order sorted by organism 

2. For the -sort flag, implement a print_sorted_counts(filename) which is similar
to print_counts(filename) but sorted by the counts in decreasing order (large to small)
and only those with count > 100

Use str.split('\t') to split on all columns and get the 'organism column'

Workflow: don't build the whole program at once. Get it to an intermediate
milestone and print your data structure and sys.exit.
When that's working, try for the next milestone.

"""

import sys
import argparse

# **** Write your code code here
# Define a read_file function that reads the file and returns a organism -> count dictionary.
# Call that function to read in the dictionary from print_counts() and print_sorted_counts()
def read_file(filename):
  d={}
  return d



# print_count,  print out the the counts for each organism sorted by the organism name
def print_counts(filename):
  d=read_file(filename)
  print('print_counts: Needs to be implemented...')


# print_sorted_counts, print out the counts for each organism with >100 counts and sorted by counts.
def print_sorted_counts(filename):
  d=read_file(filename)
  print('print_sorted_counts: Needs to be implemented...')


def main():
  parser=argparse.ArgumentParser(description='Organismcounter')
  parser.add_argument('filename',metavar='FILENAME', type=str)
  parser.add_argument('-count',action='store_true',help='count organism',default=False)
  parser.add_argument('-sort',action='store_true',default=False)
  args=parser.parse_args()

  filename=args.filename
  if args.count:
    print_counts(filename)
  elif args.sort:
    print_sorted_counts(filename)
  else:
    print('You need to give -count or -sort argument')
  

if __name__ == '__main__':
  main()
